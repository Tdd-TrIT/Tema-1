package com.sergiotrapiello.cursotesting;

/**
 * Hello world!
 *
 */
public class HelloWorld {

	public String greet() {
		return "Hello World!";
	}
}
